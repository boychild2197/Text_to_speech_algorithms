# ForwardTacotron Project Page

We use [Jekyll](https://jekyllrb.com/) to generate our project page.

### Usage

To serve locally run:
```
bundle exec jekyll serve
```